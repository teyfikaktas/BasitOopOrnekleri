package com.company;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import static com.company.ToDoMechanism.toDoMaterials;


class MainClass{


    public static void main(String[] args) {


        System.out.println(OpeningScene.WelcomeText);
        Scanner scanner= new Scanner(System.in);
        String Prefer = scanner.nextLine();
        if(Prefer.equals(TypingSystem.PreferName)){
        TypingSystem.Starting();





        }







    }

    public static  String TranslateString (boolean bool){
      if(bool){
          return ToDoSettings.Test_Styles.Color_Green+ "Completed"+ToDoSettings.Test_Styles.Reset_Color;

      }
    else
        return  ToDoSettings.Test_Styles.Color_Red+"is not Completed"+ToDoSettings.Test_Styles.Reset_Color;
    }




    }

class TypeModule{

    void typeStyle(){

    }




    }








