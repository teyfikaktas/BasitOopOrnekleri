package com.company;

public  class OpeningScene {
    static public String WelcomeText= "Hello, Welcome. " +
            "I realize that this is your first login to the system. " +
            "My name  is " + ToDoSettings.Test_Styles.getAsistantName()
            +" and I am your to-do list assistant.\n" +
            "You can change the way you call me (which you'll see I don't really prefer.)\n" +
            "If you want, you can contact me by writing.\n" +
            "If you want, you can also contact me by writing numbers (You can change this at any time from the settings tab.)" +
            "\n" +
            "If you don't know how the system works, you can write \"info\"." +
            "If you know how the system works, please make a choice about letters or writing.\n" +
            "You can write \"type\" to talk to me in writing, and \"1\" (not including punctuation marks) for the number."
            ;


}
