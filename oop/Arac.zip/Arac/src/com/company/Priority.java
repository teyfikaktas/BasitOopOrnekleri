package com.company;

public class Priority {


    enum Level{
      LOW,
        MEDIUM,
        HIGH,

    }
}
