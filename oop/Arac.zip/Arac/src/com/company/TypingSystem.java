package com.company;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public  class TypingSystem extends ToDoMechanism {
    static Scanner scan = new Scanner(System.in);

    public static String PreferName = "type";
    private static String UserNames = "Default";
    public static String WelcomeText = "Welcome again. Can I know your name?";
    Scanner scanneran = new Scanner(System.in);
    static int indexNo = 0;

    public static String getUserNames() {
        return UserNames;
    }

    public static void setUserNames(String userNames) {
        UserNames = userNames;
    }

    void PrintScreenType() {
        setUserNames(scan.nextLine());
    }

    public static void Starting() {
        Scanner scanner = new Scanner(System.in);
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println(TypingSystem.WelcomeText);
        TypingSystem.setUserNames(scanner.nextLine());
        System.out.println("Welcome " + TypingSystem.getUserNames() + " today time " + FormatterDateTime.Formatter(localDateTime) + " I see that you haven't prepared a to-do list for today. What can I do for you?");

        MethodsList();
        StartingWhile();

    }

    @Override
    public void NotComplatedıtem() {
        if (toDoMaterials.size() > 0) {

            for (int i = 0; i < toDoMaterials.size(); i++) {
            if(toDoMaterials.get(i).getIs_Completed()==true){

                System.out.println();
                System.out.print(toDoMaterials.get(i).getTitle() + "         ");
                System.out.print(toDoMaterials.get(i).getDescription() + "         ");
                System.out.print(toDoMaterials.get(i).getRemaindate() + "         ");
                System.out.print(LevelStyle(toDoMaterials.get(i).getLevel()) + "         ");
                System.out.print(MainClass.TranslateString(toDoMaterials.get(i).getIs_Completed()) + "            ");
                System.out.println();
            } }
        } else
            System.out.println("The to-do list appears empty. You can type \"create new todo\" to add a to-do list. ");

        StartingWhile();

    }



    @Override
    public int ListAllItem() {

        if (toDoMaterials.size() > 0) {

            for (int i = 0; i < toDoMaterials.size(); i++) {


                System.out.println();
                System.out.print(toDoMaterials.get(i).getTitle() + "         ");
                System.out.print(toDoMaterials.get(i).getDescription() + "         ");
                System.out.print(toDoMaterials.get(i).getRemaindate() + "         ");
                System.out.print(LevelStyle(toDoMaterials.get(i).getLevel()) + "         ");
                System.out.print(MainClass.TranslateString(toDoMaterials.get(i).getIs_Completed()) + "            ");
                System.out.println();
            }
        } else
            System.out.println("The to-do list appears empty. You can type \"create new todo\" to add a to-do list. ");

        StartingWhile();

        return 0;
    }

    @Override
    public int AddItem(int index) {
        Scanner scanner = new Scanner(System.in);
        ToDoMaterial temporary = new ToDoMaterial();
        System.out.println("Please write the title of the to-do list item you want to add.");
        String title = scanner.nextLine();
        temporary.setTitle(title);
        System.out.println("Please write the description of the to-do list item you want to add.(max 30 characters)");
        String description = scanner.nextLine();
        temporary.setDescription(description);
        temporary.setIs_Completed(false);
        LocalDateTime localDateTime = LocalDateTime.now();
        temporary.setRemaindate(FormatterDateTime.Formatter(localDateTime));
        System.out.println("Please select  priority Level(type HIGH,MEDIUM,LOW)");
        String PriorityLevel = scanner.nextLine();
        if (PriorityLevel.equals("low")) {
            temporary.setLevel(Priority.Level.LOW);

        } else if (PriorityLevel.equals("medium")) {
            temporary.setLevel(Priority.Level.MEDIUM);

        } else if (PriorityLevel.equals("high")) {
            temporary.setLevel(Priority.Level.HIGH);

        } else {
            System.out.println("Please try again");
            AddItem(index);
        }


        System.out.println("Your item has been successfully added to the to-do list.\n" +
                "I refer you to other options.");


        toDoMaterials.add(index, temporary);


        return 0;
    }

    @Override
    public int UpdateItem(int indexNo) {
        Scanner scanner = new Scanner(System.in);
        if (toDoMaterials.size() > 0) {
            System.out.println("Please type the  name at you want to update the item first");
            String UpdateItem = scanner.nextLine();

            if (UpdateItem.equals("title")) {

                System.out.println("Please first write the index number and the new title you want to change, leaving a space.\n" +
                        "(for example \"1" +
                        " sample\")");
                String newTitle = scanner.nextLine();
                String[] NewTitlee = newTitle.split(" ");
                int indexnumber = Integer.parseInt(NewTitlee[0]);
                String newTitleValue = NewTitlee[1];
                if (newTitleValue.length() >= 3 && newTitleValue.length() < 100) {
                try{
                    toDoMaterials.get(indexnumber).setTitle(newTitleValue);

                }
                catch (IndexOutOfBoundsException e){
                    System.out.println("Please type valid characters");
                    UpdateItem(indexNo);
                }
                    System.out.println("The title has been successfully updated.");
                    return 0;

                } else {
                    System.out.println("title word It should be between 3 and 100 letters, Please try again. ");
                    UpdateItem(indexNo);
                    return 0;

                }
            }
            if (UpdateItem.equals("description")) {

                System.out.println("Please first write the index number and the new description you want to change, leaving a space.\n" +
                        "(for example \"1" +
                        " sample\")");
                String newTitle = scanner.nextLine();
                String[] NewTitlee = newTitle.split(" ");
                int indexnumber = Integer.parseInt(NewTitlee[0]);
                String newDescriptionValue = NewTitlee[1];
                if (newDescriptionValue.length() > 3 && newDescriptionValue.length() < 100) {
                    toDoMaterials.get(indexnumber).setDescription(newDescriptionValue);
                    System.out.println("The Description value has been successfully updated.");
                    return 0;

                } else {
                    System.out.println("Description word It should be between 3 and 100 letters, Please try again. ");
                    UpdateItem(indexNo);
                    return 0;

                }
            }
            if (UpdateItem.equals("level")) {




                System.out.println("Please first write the index number and the new importance level you want to change, leaving a space.\n" +
                        "(for example \"1" +
                        " sample\")");
                String newTitle = scanner.nextLine();
                String[] NewTitlee = newTitle.split(" ");
                int indexnumber = Integer.parseInt(NewTitlee[0]);
                String newLevelValue = NewTitlee[1];
                if (newLevelValue.equals("low")) {
                    toDoMaterials.get(indexnumber).setLevel(Priority.Level.LOW);
                    System.out.println("priority level has been successfully changed.");

                } else if (newLevelValue.equals("medium")) {
                    toDoMaterials.get(indexnumber).setLevel(Priority.Level.MEDIUM);
                    System.out.println("priority level has been successfully changed.");


                } else if (newLevelValue.equals("high")) {
                    toDoMaterials.get(indexnumber).setLevel(Priority.Level.HIGH);
                    System.out.println("priority level has been successfully changed.");


                } else System.out.println("try again");

            }
             } else
            System.out.println("The to-do list appears empty. You can type \"create new todo\" to add a to-do list. ");



return  0;
}

    @Override
    public int CompleteItem() {
        if (toDoMaterials.size() > 0) {
            System.out.println("please type the index number of the item you want to complete. \n");
            int Index = scan.nextInt();

                try {
                    toDoMaterials.get(Index).setIs_Completed(true);
                    System.out.println("todo item successfully completed.");
                    return 0;

                } catch (IndexOutOfBoundsException e) {
                    System.out.println("Please type valid characters");
                    CompleteItem();
                    return 0;

                }

            } else {
            System.out.println("The to-do list appears empty. You can type \"create new todo\" to add a to-do list. ");
                return 0;

            }

    }

    @Override
    public int DeleteItem(int indexNo) {

if(toDoMaterials.size()>0){
    System.out.println("Please enter the sequence number of the item you want to delete.");
    String SelectedItem= scan.nextLine();
    System.out.println("Are you sure you want to delete this item?\n" +
            "Please write yes or no.");

    String choice = scan.nextLine();
    while(true){
        if(choice.equals("yes")) {
            try{
                toDoMaterials.remove(Integer.parseInt(SelectedItem));

            }
            catch (IndexOutOfBoundsException e){
                System.out.println("Please enter valid characters.");
                DeleteItem(indexNo);
            }
            System.out.println("The deletion is  complete.");

            return 0;
        }
        if(choice.equals("no")) {
            System.out.println("The deletion is not complete.");
            System.out.println("exiting...");
            return 0;
        }
        return 0;
    }
}
else
    System.out.println("The to-do list appears empty. You can type \"create new todo\" to add a to-do list. ");

        return 0;
    }

    @Override
    public void PrintAllCommands() {
   ToDoMechanism.MethodList();
    }
 public static void StartingWhile(){

     while (true) {
         System.out.println("Welcome " + TypingSystem.getUserNames() + " today time " + FormatterDateTime.getFormattedDate() + " What can I do for you?");
         String SelectedCommand = scan.nextLine();
         int Exist = CommandsArray.indexOf(SelectedCommand);
         System.out.println(Exist);
         if (Exist == 0) {
             TypingSystem typingSystem = new TypingSystem();
             System.out.print(ToDoSettings.Test_Styles.Color_Blue+"Title "+"         ");
             System.out.print(ToDoSettings.Test_Styles.Color_White+"Description "+"         ");
             System.out.print(ToDoSettings.Test_Styles.Color_Blue+"Creation date "+"         ");
             System.out.print(ToDoSettings.Test_Styles.Color_Cyan+"Level "+"         ");
             System.out.println(ToDoSettings.Test_Styles.Color_Cyan+"Completion status "+"         "+ToDoSettings.Test_Styles.Reset_Color);
             typingSystem.ListAllItem();
         }
         if(Exist == 1){

             TypingSystem typingSystem = new TypingSystem();
             typingSystem.AddItem(indexNo);

         }
         if(Exist == 2){
             TypingSystem typingSystem = new TypingSystem();
             typingSystem.UpdateItem(indexNo);

         }
         if(Exist==3){
             TypingSystem typingSystem = new TypingSystem();
             typingSystem.DeleteItem(indexNo);
         }
         if(Exist==4){
             TypingSystem typingSystem = new TypingSystem();

             System.out.println("Method list is loading...");
             System.out.println("there are...");
             typingSystem.PrintAllCommands();
         }
         if(Exist==5){
             TypingSystem typingSystem = new TypingSystem();

          typingSystem.CompleteItem();
         }
         if(Exist==6){
             TypingSystem typingSystem = new TypingSystem();

             typingSystem.NotComplatedıtem();
         }
         if(Exist==-1){
             System.out.println("The command you entered does not exist in my functions.\n Please Try Again.");
             System.out.println("Please type \"commandlist\" to see the command list.");

         }

}
     }
 }




